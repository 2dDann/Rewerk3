package com.example.rewerk3;

import android.os.Bundle;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class DetailActivity extends AppCompatActivity {

    TextView tv_descUsername, tv_descDob, tv_location, tv_email, tv_phone, tv_description;
    RatingBar descRating;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        tv_descUsername = findViewById(R.id.tv_descUsername);
        tv_descDob = findViewById(R.id.tv_descDob);
        tv_location = findViewById(R.id.tv_location);
        tv_email = findViewById(R.id.tv_email);
        tv_phone = findViewById(R.id.tv_phone);
        tv_description = findViewById(R.id.tv_description);
        descRating = findViewById(R.id.descRating);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            tv_descUsername.setText(bundle.getString("name"));
            tv_descDob.setText(bundle.getString("dob"));
            tv_location.setText(bundle.getString("location"));
            tv_email.setText(bundle.getString("email"));
            tv_phone.setText(bundle.getString("phone"));
            tv_description.setText(bundle.getString("description"));


//            String username = bundle.getString("username");
//            String dob = bundle.getString("dob");
//            tv_descUsername.setText(username);
//
//            // Retrieve user information from the Firebase Realtime Database
//            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("users");
//            Query query = reference.orderByChild("username").equalTo(username);
//            query.addValueEventListener(new ValueEventListener() {
//                @Override
//                public void onDataChange(@NonNull DataSnapshot snapshot) {
//                    if (snapshot.exists()) {
//                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
//                            HelperClass user = dataSnapshot.getValue(HelperClass.class);
//                            if (user != null) {
//                                displayUser(user);
//                            }
//                        }
//                    }
//                }
//
//                @Override
//                public void onCancelled(@NonNull DatabaseError error) {
//                    // Handle the error
//                }
//            });
        }

        descRating.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                // Update the rating value in the Firebase Realtime Database
                DatabaseReference reference = FirebaseDatabase.getInstance().getReference("users");
                Query query = reference.orderByChild("username").equalTo(tv_descUsername.getText().toString());
                query.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                                String userId = dataSnapshot.getKey();

                                // Update the rating values
                                reference.child(userId).child("noRating").setValue(rating);
                                reference.child(userId).child("totalRating").setValue(calculateTotalRating(snapshot, rating));
                            }
                            showConfirmationDialog();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        // Handle the error
                    }
                });
            }
        });
    }

    // Method to calculate the total rating based on the current rating and existing ratings
    private float calculateTotalRating(DataSnapshot snapshot, float currentRating) {
        float totalRating = 0;
        int numRatings = 0;

        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
            HelperClass user = dataSnapshot.getValue(HelperClass.class);
            if (user != null) {
                totalRating += user.getNoRating();
                numRatings++;
            }
        }

        totalRating += currentRating;
        numRatings++;

        return totalRating / numRatings;
    }

    // Show a confirmation dialog after rating
    private void showConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Rating Confirmation")
                .setMessage("Thank you for rating!")
                .setPositiveButton("OK", null)
                .show();
    }

}
