package com.example.rewerk3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ListingsActivity extends AppCompatActivity {

    private TextView usernameTextView;
    private TextView phoneTextView;
    private TextView locationTextView;
    private TextView specializationTextView;
    private TextView dobTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listings);

        usernameTextView = findViewById(R.id.item_usernameTextView);
        phoneTextView = findViewById(R.id.item_phoneTextView);
        locationTextView = findViewById(R.id.item_locationTextView);
        specializationTextView = findViewById(R.id.item_specializationTextView);
        dobTextView = findViewById(R.id.item_dobTextView);

        CardView cardView = findViewById(R.id.cardView);
        cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the selected user's data
                String username = usernameTextView.getText().toString();
                String dob = dobTextView.getText().toString();
                String location = locationTextView.getText().toString();
                String phone = phoneTextView.getText().toString();
                String desc = specializationTextView.getText().toString();

                // Launch the detail activity and pass the data through intent
                Intent intent = new Intent(ListingsActivity.this, DetailActivity.class);
                intent.putExtra("username", username);
                intent.putExtra("dob", dob);
                intent.putExtra("location", location);
                intent.putExtra("phone", phone);
                intent.putExtra("description", desc);
                startActivity(intent);
            }
        });

        DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("users");
        usersRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String previousChildName) {
                HelperClass user = dataSnapshot.getValue(HelperClass.class);
                if (user != null) {
                    displayUser(user);
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String previousChildName) {
                // Handle child changed event if needed
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {
                // Handle child removed event if needed
            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String previousChildName) {
                // Handle child moved event if needed
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle error
            }
        });
    }

    private void displayUser(HelperClass user) {
        usernameTextView.setText(user.getUsername());
        phoneTextView.setText(user.getPhone());
        locationTextView.setText(user.getLocation());
        specializationTextView.setText(user.getSpecialization());
        dobTextView.setText(user.getDob());
    }
}
